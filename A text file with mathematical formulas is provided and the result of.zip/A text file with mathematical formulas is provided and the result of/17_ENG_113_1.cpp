// 17/ENG/113//
// Department of computer engineering//
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <conio.h>
#include <stack>
#include <iomanip>

using namespace std;

//function to check whether the expressions are paired
bool ArePaired(char openBrac, char closeBrac)
{
	if (openBrac == '(' && closeBrac == ')')
	{
		return true;
	}
	else if (openBrac == '{' && closeBrac == '}')
	{
		return true;
	}
	else if (openBrac == '[' && closeBrac == ']')
	{
		return true;
	}
	return false;
}

//function to check whether the expressions are balanced
bool checkParentheses(string expression)
{
	//have used stack header file
	stack<char>  S;
	for (int i = 0; i < expression.length(); i++)
	{
		if (expression[i] == '(' || expression[i] == '{' || expression[i] == '[')
		{
			S.push(expression[i]);
		}
		else if (expression[i] == ')' || expression[i] == '}' || expression[i] == ']')
		{
			if (S.empty() || !ArePaired(S.top(), expression[i]))
			{
				return false;
			}
			else
			{
				S.pop();
			}
		}
	}
	return S.empty() ? true : false;
}

//from here  functions to evaluate the value of the expression is coded
//get the address of the expression
char* expressionTOanalyze;


char peek()
{
	return *expressionTOanalyze;
}

char get()
{
	return *expressionTOanalyze++;
}

float expression();

//check whether the num is between 0 to 9
float number()
{
	float result = get() - '0';
	while (peek() >= '0' && peek() <= '9')
	{
		result = 10 * result + get() - '0';
	}
	return result;
}

//check ( ) and numbers
float factor()
{
	if (peek() >= '0' && peek() <= '9')
	{
		return number();
	}
	else if (peek() == '(')
	{
		get(); // '('
		float result = expression();
		get(); // ')'
		return result;
	}
	else if (peek() == '-')
	{
		get();
		return -factor();
	}
	return 0; 
}

//check * and / symbols and return result
float term()
{
	float result = factor();
	while (peek() == '*' || peek() == '/')
	{
		if (get() == '*')
		{
			result *= factor();
		}
		else
		{
			result /= factor();
		}
	}
	return result;
}

// check + and - symbols and return result
float expression()
{
	float result = term();
	while (peek() == '+' || peek() == '-')
	{
		if (get() == '+')
		{
			result += term();
		}
		else
		{
			result -= term();
		}
	}
	return result;
}

int main()
{

	int a1 = 0;
	string* arrr = NULL;  
	arrr = new  string[1000]; 

	string lines;
	ifstream file("formulas.txt");  // reading formuls.txt file
	ofstream outfile("result.txt");   // writing results.txt file

	cout << "                      We are going to evaluate the values of these expressions " << endl;


	// when the file is open these things are done
	if (file.is_open())
	{
		while (getline(file, lines))
		{
			arrr[a1].append(lines);//used to add string to the end of another string
			cout << arrr[a1] ;
			//check whether it is balanced
			if (checkParentheses(arrr[a1]))
			{
				expressionTOanalyze = &lines[0];
				float result = expression();
				//checking precison  - setprecision
				//upto 2 decimal points  - fixed
				cout << setprecision(2)<<fixed<<result<<endl<<endl;
				outfile << setprecision(2) << fixed<<arrr[a1]<<result << endl; 
				//write values in to results.txt file
			}
			else 
			{
				cout << "Not Balanced" << endl;
				outfile << arrr[a1] << "Not Balanced" << endl;
			}
			a1++;
		}
		//opended files are closed
		file.close();
		outfile.close();
	}
	system("pause");
	return 0;
}
